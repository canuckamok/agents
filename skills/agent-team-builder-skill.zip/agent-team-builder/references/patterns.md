# Team Patterns

Use this file when deciding whether a workflow should stay as one agent or be split into a repeatable team.

Always start with the smallest workable architecture. Add agents only when they reduce fragility, improve permission safety, make handoffs testable, or create clear operational value.

## Selection order

Choose in this order:

1. `single_agent`
2. `manager_team`
3. `handoff_team`

Do not choose a larger pattern unless the smaller one is clearly insufficient.

## Viability checklist

Before selecting a pattern, confirm enough of the scenario is known:

- goal
- input source
- final output
- trigger or cadence
- tools and permissions
- human review boundary
- failure modes
- success criteria

If the scenario is too vague, recommend a discovery step before building a team.

## Pattern 1: `single_agent`

Use when one agent can reliably handle the workflow with a clear prompt, limited tools, and a manageable number of steps.

Best for:

- light research and synthesis
- one-pass transformations
- simple scheduled digests
- workflows with one main output
- low-risk tasks with no complex handoffs
- tasks where intermediate files are helpful but not required

Good signs:

- one output owner
- one schedule
- one tool scope
- low coordination overhead
- no meaningful permission separation
- final result can be validated directly

Avoid when:

- the prompt becomes too long or fragile
- different stages need different tools or permissions
- the workflow needs durable intermediate artifacts
- one stage must be reviewed before the next stage runs
- failures are hard to locate without stage boundaries

Minimum design:

- one agent contract
- one output contract
- one eval
- one stop condition for recurring runs

## Pattern 2: `manager_team`

One coordinator assigns work to specialist agents, collects outputs, validates them, and decides what runs next.

Best for:

- branching workflows
- workflows with optional stages
- tasks that need one point of control
- teams where one agent should own final assembly or approval routing
- workflows where specialists need different tool scopes

Good signs:

- multiple specialists, one final owner
- stages may run conditionally
- strong need for centralized logging or review
- outputs need arbitration, ranking, or synthesis
- user wants one place to approve or redirect the workflow

Recommended shape:

- 1 manager
- 1-2 specialists
- optional reviewer only if the user asks or risk is high

Guardrails:

- manager may assign, validate, merge, and escalate
- manager must not duplicate specialist work unless validation fails
- specialists should not talk to each other directly unless documented
- final output ownership must stay with the manager or one named downstream agent
- specialists must return structured outputs, not conversational progress notes
- manager must record which specialist output was accepted, rejected, or escalated

Common failure modes:

- manager becomes a bloated super-agent
- specialists have overlapping missions
- no one owns final output quality
- validation is subjective and undocumented

## Pattern 3: `handoff_team`

Agents pass work stage to stage in a fixed sequence.

Best for:

- linear pipelines
- recurring reports
- workflows with durable file artifacts between stages
- cases where each stage has a clear input and output contract
- workflows where each stage can be tested independently

Good signs:

- stable order of execution
- each stage transforms a file or dataset
- upstream outputs are easy to validate before downstream use
- review gates occur between stages
- downstream agents should not need upstream tools

Recommended shape:

- 2-3 agents
- one input file per stage when possible
- one output owner per artifact
- validation before each handoff

Guardrails:

- define exact file contracts between stages
- define what happens if an upstream file is missing or invalid
- add a stop condition so the pipeline cannot loop forever
- no shared write ownership without a lock or merge contract
- every downstream stage validates its input before proceeding

Common failure modes:

- hidden handoffs in prose
- downstream agent guesses the upstream format
- pipeline continues after invalid input
- no state file, so failures are invisible

## Pattern choice checklist

Choose `single_agent` if most answers are yes:

- can one agent own the final output?
- can one prompt describe the workflow without becoming brittle?
- do all steps use the same tools and permissions?
- are intermediate files optional rather than required?
- is failure easy for the user to spot?

Choose `manager_team` if most answers are yes:

- do stages branch or run conditionally?
- should one agent decide which specialists run?
- does one agent need to assemble the final output?
- is centralized oversight important?
- do specialists need different permission boundaries?

Choose `handoff_team` if most answers are yes:

- is the workflow mostly linear?
- does each stage produce a durable artifact?
- are handoff contracts more important than centralized decision-making?
- can each stage be tested independently?
- should downstream agents work from files rather than shared conversational context?

## Example patterns

### Daily signal pipeline

Pattern: `handoff_team`

- Scout: gathers source material
- Synthesizer: turns findings into a draft
- Editor: produces final publishable output

Flow:

`Scout -> raw-signals/YYYY-MM-DD.md -> Synthesizer -> drafts/YYYY-MM-DD.md -> Editor -> reports/YYYY-MM-DD.md`

Why this works:

- linear order
- durable files
- clear stage ownership
- easy evals per artifact

### Research with conditional escalation

Pattern: `manager_team`

- Coordinator: decides what to investigate
- Researcher: gathers evidence
- Analyst: compares findings
- Coordinator: assembles final memo

Why this works:

- not every stage runs every time
- one agent owns the final answer
- easy to insert review checkpoints
- manager can escalate uncertainty

### Lightweight weekly digest

Pattern: `single_agent`

- Digest agent: gathers, summarizes, formats, publishes to a draft location

Why this works:

- one schedule
- one output
- no real handoff value
- coordination would add overhead

## Anti-patterns

Avoid these:

### Too many agents too early

Do not create a team just because the task has multiple steps.

### Shared ownership

Do not let multiple agents write to the same final file unless the contract is explicit.

### Tool sprawl

Do not give all agents the same broad tool access by default.

### Hidden handoffs

Do not rely on implicit knowledge of where files live or what format they should have.

### Persona-first design

Do not start with characters or style motifs before defining mission, inputs, outputs, and success criteria.

### Manager-as-worker

Do not let a manager agent redo every specialist task. The manager coordinates, validates, merges, and escalates.

### Untestable stages

Do not create a stage if there is no way to check whether it succeeded.

## Minimum per-agent contract

Every agent in any pattern should define:

- `name`
- `mission`
- `inputs`
- `outputs`
- `tools_allowed`
- `tools_forbidden`
- `reads_from`
- `writes_to`
- `trigger`
- `schedule`
- `success_criteria`
- `failure_mode`
- `escalation_rule`
- `requires_human_review_before`

## Minimum file contract

Every durable artifact should define:

- `path`
- `owner`
- `producer`
- `consumer`
- `format`
- `required_fields`
- `freshness_requirement`
- `validation_rule`
- `overwrite_or_append_behavior`
- `failure_behavior_if_missing_or_invalid`

## Minimum eval contract

Every stage should define:

- `test_name`
- `test_input`
- `expected_output`
- `pass_criteria`
- `fail_criteria`
- `how_to_run_or_check`
