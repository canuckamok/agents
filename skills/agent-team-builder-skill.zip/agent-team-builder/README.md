# Agent Team Builder Skill

This skill helps design and scaffold reliable repeatable agent teams.

It emphasizes:

- smallest workable architecture
- single-agent-first reasoning
- explicit file contracts
- strict permission boundaries
- observable state
- stage-level evals
- approval before scaffolding or scheduling

## Contents

- `SKILL.md` — main skill instructions
- `references/patterns.md` — architecture selection guide
- `scripts/scaffold.py` — local scaffold generator
- `examples/competitor-monitor-team-brief.md` — example approved design brief

## Scaffold example

```bash
python scripts/scaffold.py \
  --team-name competitor-monitor \
  --architecture handoff_team \
  --agents Scout Synthesizer Editor
```

The script creates `agents/<team-name>/` with `PIPELINE.md`, `AGENTS.md`, `EVALS.md`, `STATE.md`, and per-agent `SOUL.md` files.

It does not create schedules, cron jobs, external automations, or destructive actions.
