# Example Team Brief: Competitor Monitor

## Recommendation

`handoff_team`

A single agent could produce a weekly memo, but the workflow benefits from durable research and draft artifacts so each stage can be validated independently.

## Flow

`Scout -> raw-signals/YYYY-MM-DD.md -> Synthesizer -> drafts/YYYY-MM-DD.md -> Editor -> reports/YYYY-MM-DD.md`

## Agents

### Scout

- mission: collect relevant competitor updates
- inputs: approved competitor list and source list
- outputs: `raw-signals/YYYY-MM-DD.md`
- tools_allowed: web/search/read-only sources
- tools_forbidden: publish, send email, delete files
- reads_from: `inputs/competitors.md`
- writes_to: `raw-signals/`
- trigger: weekly manual or approved schedule
- schedule: none until approved
- success_criteria: at least 3 cited relevant updates or explicit no-news finding
- failure_mode: source unavailable or uncited claims
- escalation_rule: stop and ask for review if fewer than 3 sources are available
- requires_human_review_before: none, because Scout only writes internal files

### Synthesizer

- mission: convert raw signals into product implications
- inputs: `raw-signals/YYYY-MM-DD.md`
- outputs: `drafts/YYYY-MM-DD.md`
- tools_allowed: local file read/write in assigned directories
- tools_forbidden: web, publish, send email, delete files
- reads_from: `raw-signals/`
- writes_to: `drafts/`
- trigger: valid Scout output exists
- schedule: downstream of Scout
- success_criteria: draft includes themes, implications, confidence, and source references
- failure_mode: missing or invalid raw signals
- escalation_rule: stop and return validation errors
- requires_human_review_before: none

### Editor

- mission: produce final memo for human review
- inputs: `drafts/YYYY-MM-DD.md`
- outputs: `reports/YYYY-MM-DD.md`
- tools_allowed: local file read/write in assigned directories
- tools_forbidden: publish, send email, delete files
- reads_from: `drafts/`
- writes_to: `reports/`
- trigger: valid Synthesizer draft exists
- schedule: downstream of Synthesizer
- success_criteria: report is concise, actionable, and clearly sourced
- failure_mode: unsupported claims or unclear recommendation
- escalation_rule: mark `needs_review`
- requires_human_review_before: sending or publishing final report

## File contract example

```yaml
path: raw-signals/YYYY-MM-DD.md
owner: Scout
producer: Scout
consumer: Synthesizer
format: markdown_table
required_fields: [source_url, title, date_seen, summary, relevance_score]
optional_fields: [notes, confidence]
freshness_requirement: created during current run
overwrite_or_append_behavior: overwrite per run date
validation_rule: every row has source_url and date_seen; relevance_score is 1-5
failure_behavior_if_missing_or_invalid: stop pipeline and escalate to human
```

## Eval example

```yaml
test_name: Scout captures cited raw signals
test_input: approved competitor list with 3 competitors
expected_output: raw-signals/YYYY-MM-DD.md
pass_criteria: at least 3 valid cited rows or explicit no-news finding
fail_criteria: uncited claims, missing dates, or irrelevant sources
how_to_run_or_check: inspect markdown table and required fields
```
