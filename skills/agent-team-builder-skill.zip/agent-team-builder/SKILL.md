---
name: agent-team-builder
description: Build repeatable multi-agent workflow teams for tasks that require distinct stages, explicit handoffs, durable file contracts, separate tool permissions, schedules, or review gates. Use when the user explicitly asks for a team, pipeline, crew, reusable agent workflow, or when a task clearly benefits from specialized subagents after confirming that a single agent with tools is insufficient. First test scenario viability, then propose the smallest architecture, require approval before scaffolding, and only then generate agent specs, team docs, schedules, file contracts, evals, and operational notes.
---

# Agent Team Builder

Design the smallest reliable workflow team that can run repeatedly, be inspected, and fail safely.

Default to a single agent first. Split into multiple agents only when the workflow has clearly separable stages, conflicting tool scopes, heavy prompt complexity, durable handoffs, branching control flow, or review gates that materially improve reliability.

## Core principle

A good agent team is not a collection of personas. It is an operational workflow with clear ownership, limited permissions, explicit file contracts, observable state, and testable stage outputs.

## Workflow

### 1. Clarify the scenario

Identify:

- goal
- user or business outcome
- input sources
- final output destination
- systems or tools touched
- cadence or trigger
- human approval needs
- failure sensitivity
- privacy, security, or destructive-action risks

Do not over-question. If the user has provided enough to make a reasonable proposal, proceed and mark assumptions explicitly.

### 2. Run the viability gate

Before proposing an agent team, confirm the scenario has enough operational shape.

A scenario is viable only if most of these are known or can be safely assumed:

- clear goal
- known input source
- known final output
- repeatable trigger or clear manual run command
- available tools or permissions
- observable success criteria
- known human approval boundary
- identifiable failure modes

If two or more critical items are missing, do not design a full team yet. Either ask targeted clarification questions or propose a single-agent discovery step whose output is a viable team brief.

### 3. Choose the architecture

Use `references/patterns.md` and choose in this order:

1. `single_agent` — one agent with tools
2. `manager_team` — one coordinator delegates to specialists
3. `handoff_team` — agents pass work stage to stage

Do not assume a team is needed just because the task has multiple steps.

### 4. Propose the smallest viable design

Start with 1-3 agents max unless the user explicitly asks for more or the scenario truly requires more.

For each agent, provide the full agent contract:

- `name`
- `mission`
- `inputs`
- `outputs`
- `tools_allowed`
- `tools_forbidden`
- `reads_from`
- `writes_to`
- `trigger`
- `schedule`
- `success_criteria`
- `failure_mode`
- `escalation_rule`
- `requires_human_review_before`

Also show:

- architecture type
- why smaller architecture is insufficient, if not `single_agent`
- handoff order
- file contracts
- approval checkpoints
- run-state location
- stop condition
- concrete eval or test case per stage

Keep the proposal concise enough that the user can approve or edit quickly.

### 5. Wait for approval

Do not scaffold files, create schedules, write cron jobs, or modify persistent team docs until the user approves the design.

Approval can be explicit, such as “approved,” “build it,” “scaffold this,” or equivalent.

### 6. Build after approval

After approval:

- use `scripts/scaffold.py`
- create the team directory
- create or customize each agent's `SOUL.md`
- create or update team `AGENTS.md`
- create `agents/<team-name>/PIPELINE.md`
- create `agents/<team-name>/EVALS.md`
- create `agents/<team-name>/STATE.md`
- create any contract directories needed by the proposed workflow

### 7. Document the pipeline

`PIPELINE.md` must include:

- team purpose
- architecture type
- why this is the smallest reliable architecture
- agent roster
- dependency graph
- per-stage file contracts
- schedules or manual triggers
- stop conditions
- retry or fallback behavior
- manual review checkpoints
- logging locations
- current state location
- permission boundaries

### 8. Register and log

- register agents in team `AGENTS.md` under `## Current Staff`
- log what changed in `memory/YYYY-MM-DD.md` if the host project has a memory folder
- update `MEMORY.md` only for significant changes

Significant changes are:

- new or retired agents
- changed file contracts
- changed schedules
- changed approval policy
- changed tool permissions
- recurring failure patterns

## Architecture rules

- prefer a single agent when it can do the job reliably
- start with 1-3 agents max
- keep responsibilities non-overlapping
- give each agent only the tools and write access it actually needs
- define forbidden tools, not only allowed tools
- do not let two agents own the same output file without an explicit contract
- require a stop condition for every recurring workflow
- require human approval before autonomous schedules are created
- use memorable names only after the functional contract is clear
- use existing patterns from `references/patterns.md` before inventing a new topology
- never hide handoffs inside prose; name the artifact, owner, producer, consumer, and validation rule

## File contract schema

Each durable handoff must define:

- `path`
- `owner`
- `producer`
- `consumer`
- `format`
- `required_fields`
- `optional_fields`
- `freshness_requirement`
- `validation_rule`
- `overwrite_or_append_behavior`
- `failure_behavior_if_missing_or_invalid`

Example:

```yaml
path: raw-signals/YYYY-MM-DD.md
owner: Scout
producer: Scout
consumer: Synthesizer
format: markdown_table
required_fields: [source_url, title, date_seen, summary, relevance_score]
optional_fields: [notes, confidence]
freshness_requirement: created during current run
overwrite_or_append_behavior: overwrite per run date
validation_rule: every row has source_url and date_seen; relevance_score is 1-5
failure_behavior_if_missing_or_invalid: stop pipeline and escalate to human
```

## Permission boundary schema

For each agent define:

- `tools_allowed`
- `tools_forbidden`
- `read_scope`
- `write_scope`
- `external_actions_allowed`
- `destructive_actions_allowed`
- `requires_human_review_before`

Default stance:

- no destructive actions unless explicitly approved
- no external sending or publishing without human review
- no broad shared write access
- no agent gets all tools by default

## Stage eval schema

Each stage must include at least one concrete eval:

- `test_name`
- `test_input`
- `expected_output`
- `pass_criteria`
- `fail_criteria`
- `how_to_run_or_check`

Example:

```yaml
test_name: Scout captures cited raw signals
test_input: 5 source URLs
expected_output: raw-signals/YYYY-MM-DD.md with source_url, title, date_seen, summary, relevance_score
pass_criteria: at least 3 valid source rows; all rows include URLs and dates
fail_criteria: uncited claims, missing dates, or less than 3 usable rows
how_to_run_or_check: inspect markdown table and validate required fields
```

## Run states

Recurring workflows must use these states:

- `pending`
- `running`
- `blocked`
- `needs_review`
- `completed`
- `failed`
- `skipped`

`PIPELINE.md` must say where state is recorded. `STATE.md` is the default.

## Manager-team rules

For `manager_team`:

- the manager may assign, validate, merge, and escalate
- the manager must not independently redo specialist work unless validation fails
- the manager owns the final output unless explicitly delegated
- specialists return structured outputs, not conversational updates
- specialists should not talk to each other directly unless documented
- final assembly and approval routing must have one owner

## Handoff-team rules

For `handoff_team`:

- each stage has exactly one primary output owner
- every downstream stage validates upstream input before using it
- missing or invalid upstream artifacts stop the pipeline unless a fallback is documented
- each stage can be tested independently
- no loop is allowed without a stop condition

## Output format when proposing a team

Return:

1. recommendation: `single_agent`, `manager_team`, or `handoff_team`
2. short reason and why smaller options are or are not sufficient
3. compact agent table or bullet list with required contract fields
4. file contract table
5. simple flow diagram such as `Agent A -> file_x -> Agent B`
6. approval checkpoints and permission boundaries
7. eval/test cases per stage
8. open questions or risks
9. clear approval prompt

## Quality bar

A good team design has:

- smallest workable architecture
- explicit handoffs
- clear file ownership
- limited permissions
- forbidden permissions
- observable execution state
- defined success criteria
- defined failure handling
- defined stop conditions
- human review gates where risk requires them
- at least one concrete eval or test case per stage
- file contracts that a downstream agent can validate without guessing

## Resources

- `references/patterns.md`
- `scripts/scaffold.py`
