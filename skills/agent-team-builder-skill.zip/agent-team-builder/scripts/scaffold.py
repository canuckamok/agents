#!/usr/bin/env python3
"""Scaffold a repeatable agent team directory.

This script creates a conservative, editable scaffold for the Agent Team Builder skill.
It does not create schedules, cron jobs, external automations, or destructive actions.

Usage examples:
  python scripts/scaffold.py --team-name competitor-monitor --architecture handoff_team \
    --agents Scout Synthesizer Editor

  python scripts/scaffold.py --team-name weekly-digest --architecture single_agent \
    --agents DigestAgent --root .
"""

from __future__ import annotations

import argparse
import datetime as dt
import re
from pathlib import Path
from typing import Iterable

VALID_ARCHITECTURES = {"single_agent", "manager_team", "handoff_team"}
RUN_STATES = ["pending", "running", "blocked", "needs_review", "completed", "failed", "skipped"]


def slugify(value: str) -> str:
    value = value.strip().lower()
    value = re.sub(r"[^a-z0-9]+", "-", value)
    value = re.sub(r"^-+|-+$", "", value)
    if not value:
        raise ValueError("Team name must contain at least one letter or number.")
    return value


def agent_slug(value: str) -> str:
    value = re.sub(r"[^A-Za-z0-9_-]+", "-", value.strip())
    value = re.sub(r"^-+|-+$", "", value)
    if not value:
        raise ValueError("Agent names must contain at least one letter or number.")
    return value


def write_file(path: Path, content: str, overwrite: bool) -> bool:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and not overwrite:
        return False
    path.write_text(content.rstrip() + "\n", encoding="utf-8")
    return True


def yaml_list(items: Iterable[str]) -> str:
    items = list(items)
    if not items:
        return "[]"
    return "[" + ", ".join(items) + "]"


def soul_md(agent: str, architecture: str) -> str:
    return f"""# {agent} SOUL

## Mission

TODO: Define the single responsibility this agent owns.

## Architecture context

- team architecture: `{architecture}`
- responsibility boundary: TODO
- final output ownership: TODO

## Inputs

- TODO

## Outputs

- TODO

## Tools allowed

- TODO

## Tools forbidden

- destructive actions unless explicitly approved
- external sending or publishing unless explicitly approved
- broad filesystem writes outside documented `writes_to`

## Reads from

- TODO

## Writes to

- TODO

## Trigger

- TODO: manual, scheduled, manager-assigned, or upstream file arrival

## Schedule

- TODO: none/manual until approved

## Success criteria

- TODO

## Failure mode

- TODO

## Escalation rule

- TODO

## Requires human review before

- TODO: list any publishing, sending, deletion, or irreversible actions

## Stage eval

```yaml
test_name: TODO
test_input: TODO
expected_output: TODO
pass_criteria: TODO
fail_criteria: TODO
how_to_run_or_check: TODO
```
"""


def agents_md(team_name: str, architecture: str, agents: list[str]) -> str:
    staff = "\n".join(f"- `{agent}` — TODO: mission and ownership boundary" for agent in agents)
    return f"""# {team_name} AGENTS

## Team architecture

`{architecture}`

## Current Staff

{staff}

## Ownership rules

- Each agent owns only its documented outputs.
- No two agents may write to the same output without an explicit merge contract.
- Human approval is required before autonomous schedules, external sends, publishing, deletion, or destructive actions.
- Tool access must be limited to what each agent needs.

## Change log policy

Record significant changes in `memory/YYYY-MM-DD.md` if a memory directory exists.
Significant changes include new or retired agents, changed file contracts, changed schedules, changed approval policy, changed tool permissions, or recurring failure patterns.
"""


def pipeline_md(team_name: str, architecture: str, agents: list[str]) -> str:
    if architecture == "handoff_team" and len(agents) > 1:
        flow = " -> ".join(
            item
            for pair in zip(agents, [f"artifact-{i+1}.md" for i in range(len(agents) - 1)])
            for item in pair
        ) + f" -> {agents[-1]}"
    elif architecture == "manager_team" and agents:
        manager = agents[0]
        specialists = ", ".join(agents[1:]) if len(agents) > 1 else "TODO specialists"
        flow = f"{manager} -> [{specialists}] -> {manager} -> final-output.md"
    else:
        flow = f"{agents[0] if agents else 'Agent'} -> final-output.md"

    roster = "\n".join(f"- `{agent}`: TODO" for agent in agents)
    contracts = "\n".join(
        f"""
### Contract {i+1}: TODO artifact

```yaml
path: TODO
owner: {agent}
producer: {agent}
consumer: TODO
format: TODO
required_fields: []
optional_fields: []
freshness_requirement: TODO
validation_rule: TODO
overwrite_or_append_behavior: TODO
failure_behavior_if_missing_or_invalid: stop and escalate
```
""" for i, agent in enumerate(agents)
    )
    return f"""# {team_name} PIPELINE

## Team purpose

TODO: Describe the workflow goal and user/business outcome.

## Architecture type

`{architecture}`

## Why this is the smallest reliable architecture

TODO: Explain why a smaller architecture is sufficient or insufficient.

## Agent roster

{roster}

## Dependency graph

`{flow}`

## Run state

State is recorded in `STATE.md`.

Allowed states:

{chr(10).join(f'- `{state}`' for state in RUN_STATES)}

## File contracts

{contracts if contracts.strip() else 'TODO'}

## Schedules or manual triggers

- Default: manual only until approved.
- TODO: Add cadence, trigger, and owner.

## Stop conditions

- Stop if a required input is missing or invalid.
- Stop if validation fails twice in one run.
- Stop before external sending, publishing, deletion, or destructive action unless human approval has been granted.
- TODO: Add workflow-specific stop conditions.

## Retry or fallback behavior

- Retry only if the failure is transient and retry behavior is documented.
- Do not retry indefinitely.
- Escalate after documented retry limit.

## Manual review checkpoints

- TODO: Define review points.

## Permission boundaries

- TODO: Summarize allowed and forbidden tools per agent.

## Logging locations

- `logs/`
- `STATE.md`
- `memory/YYYY-MM-DD.md` if project memory is used
"""


def evals_md(agents: list[str]) -> str:
    sections = []
    for agent in agents:
        sections.append(f"""## {agent}

```yaml
test_name: TODO
stage_owner: {agent}
test_input: TODO
expected_output: TODO
pass_criteria: TODO
fail_criteria: TODO
how_to_run_or_check: TODO
```
""")
    return "# EVALS\n\nEach stage must have at least one concrete eval.\n\n" + "\n".join(sections)


def state_md(team_name: str) -> str:
    today = dt.date.today().isoformat()
    return f"""# {team_name} STATE

```yaml
state: pending
last_updated: {today}
current_run_id: null
current_stage: null
blocked_reason: null
needs_review_reason: null
last_successful_run: null
last_failed_run: null
```

Allowed states: {yaml_list(RUN_STATES)}
"""


def readme_md(team_name: str) -> str:
    return f"""# {team_name}

This directory was scaffolded by the Agent Team Builder skill.

Start by editing:

1. `PIPELINE.md`
2. `AGENTS.md`
3. each `agents/<agent>/SOUL.md`
4. `EVALS.md`
5. `STATE.md`

No autonomous schedules, external sends, publishing actions, or destructive actions are created by this scaffold.
"""


def main() -> None:
    parser = argparse.ArgumentParser(description="Scaffold an agent team directory.")
    parser.add_argument("--team-name", required=True, help="Human-readable team name.")
    parser.add_argument("--architecture", required=True, choices=sorted(VALID_ARCHITECTURES))
    parser.add_argument("--agents", nargs="+", required=True, help="Agent names in flow/order. For manager_team, put manager first.")
    parser.add_argument("--root", default=".", help="Project root where agents/<team-name> will be created.")
    parser.add_argument("--overwrite", action="store_true", help="Overwrite existing scaffold files.")
    args = parser.parse_args()

    team_slug = slugify(args.team_name)
    agents = [agent_slug(a) for a in args.agents]

    if args.architecture == "single_agent" and len(agents) != 1:
        raise SystemExit("single_agent architecture requires exactly one agent.")
    if args.architecture in {"manager_team", "handoff_team"} and len(agents) < 2:
        raise SystemExit(f"{args.architecture} requires at least two agents.")

    project_root = Path(args.root).resolve()
    team_dir = project_root / "agents" / team_slug

    created = []
    skipped = []

    files = {
        team_dir / "README.md": readme_md(team_slug),
        team_dir / "AGENTS.md": agents_md(team_slug, args.architecture, agents),
        team_dir / "PIPELINE.md": pipeline_md(team_slug, args.architecture, agents),
        team_dir / "EVALS.md": evals_md(agents),
        team_dir / "STATE.md": state_md(team_slug),
        team_dir / "logs" / ".gitkeep": "",
        team_dir / "contracts" / ".gitkeep": "",
        team_dir / "memory" / ".gitkeep": "",
    }

    for agent in agents:
        files[team_dir / "agents" / agent / "SOUL.md"] = soul_md(agent, args.architecture)

    for path, content in files.items():
        if write_file(path, content, args.overwrite):
            created.append(path)
        else:
            skipped.append(path)

    print(f"Scaffold complete: {team_dir}")
    print(f"Created/updated: {len(created)}")
    if skipped:
        print(f"Skipped existing files: {len(skipped)}")
        for path in skipped:
            print(f"  - {path}")


if __name__ == "__main__":
    main()
